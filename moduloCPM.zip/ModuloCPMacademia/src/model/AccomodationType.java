package model;

public enum AccomodationType {
	AP, AH, HO
}
