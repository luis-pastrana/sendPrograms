package model;

import java.util.HashMap;
import java.util.Map;

public class Catalogue {
	private Map<String, Accomodation> accomodations = new HashMap<>();
	private Map<String, Package> packages = new HashMap<>();
	private Map<String, ThemePark> themeParks = new HashMap<>();
	private Map<String, Ticket> tickets = new HashMap<>();

	public Catalogue() {
		super();
	}

	public Map<String, Accomodation> getAccomodations() {
		return accomodations;
	}

	public void setAccomodations(Map<String, Accomodation> accomodations) {
		this.accomodations = accomodations;
	}

	public Map<String, Package> getPackages() {
		return packages;
	}

	public void setPackages(Map<String, Package> packages) {
		this.packages = packages;
	}

	public Map<String, ThemePark> getThemeParks() {
		return themeParks;
	}

	public void setThemeParks(Map<String, ThemePark> themeParks) {
		this.themeParks = themeParks;
	}

	public Map<String, Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(Map<String, Ticket> tickets) {
		this.tickets = tickets;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accomodations == null) ? 0 : accomodations.hashCode());
		result = prime * result
				+ ((packages == null) ? 0 : packages.hashCode());
		result = prime * result
				+ ((themeParks == null) ? 0 : themeParks.hashCode());
		result = prime * result + ((tickets == null) ? 0 : tickets.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Catalogue other = (Catalogue) obj;
		if (accomodations == null) {
			if (other.accomodations != null)
				return false;
		} else if (!accomodations.equals(other.accomodations))
			return false;
		if (packages == null) {
			if (other.packages != null)
				return false;
		} else if (!packages.equals(other.packages))
			return false;
		if (themeParks == null) {
			if (other.themeParks != null)
				return false;
		} else if (!themeParks.equals(other.themeParks))
			return false;
		if (tickets == null) {
			if (other.tickets != null)
				return false;
		} else if (!tickets.equals(other.tickets))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Catalogue [accomodations=" + accomodations + ", packages="
				+ packages + ", themeParks=" + themeParks + ", tickets="
				+ tickets + "]";
	}

}
